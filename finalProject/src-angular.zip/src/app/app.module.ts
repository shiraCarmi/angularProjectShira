import { NgModule } from '@angular/core';
import {AppComponent} from './app.component';
import { TransportationSystemComponent } from './transportation-system/transportation-system.component';
import { BrowserModule } from '@angular/platform-browser';
import{HttpClientModule}from '@angular/common/http';
import { RouterModule,Routes } from '@angular/router';

import { VolunteerModule } from './volunteer/volunteer.module';
import { VolunteerListComponent } from './volunteer/volunteer-list/volunteer-list.component';
import { EditVolunteerComponent } from './volunteer/edit-volunteer/edit-volunteer.component';


const ROUTES : Routes=[
    
    {path:"Transportation",component:TransportationSystemComponent},
    {path:"volunteers",component:VolunteerListComponent},
    {path:"editVolunteer",component:EditVolunteerComponent}
   
    ];

@NgModule({
  declarations: [AppComponent, TransportationSystemComponent],
  imports:[BrowserModule,RouterModule.forRoot(ROUTES),VolunteerModule,HttpClientModule],
  providers:[],
  bootstrap:[AppComponent]
})

export class AppModule { 
  
}
    