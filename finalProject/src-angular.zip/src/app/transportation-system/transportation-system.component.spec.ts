import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransportationSystemComponent } from './transportation-system.component';

describe('TransportationSystemComponent', () => {
  let component: TransportationSystemComponent;
  let fixture: ComponentFixture<TransportationSystemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransportationSystemComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TransportationSystemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
