import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transportation-system',
  templateUrl: './transportation-system.component.html',
  styleUrls: ['./transportation-system.component.css']
})
export class TransportationSystemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
