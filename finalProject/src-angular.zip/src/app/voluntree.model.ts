export class volunteer{
    name:string ="" ;
    days:Boolean[] =[] ;
    id:string=""; 
    phon:string="0000000000";
    active:Boolean=true;

}